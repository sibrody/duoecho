# DuoEcho Guardrailed Controller/Worker Bundle

This bundle lets you run **any <PROMPT>** against **1..n chunked documents** with:
- A **Controller** that selects chunks, calls **Workers**, enforces **schemas**, **citations**, and a **coverage matrix**, and **fails closed** on gaps.
- **Workers** that are **persona-aware** (base persona + prompt delta + runtime tone knobs) while **guardrails remain immutable**.

## Files
- `controller_prompt.txt` – system prompt for Controller.
- `worker_template.txt` – system prompt for Workers (persona-aware, JSON-only).
- `schemas/*.json` – example JSON schemas (exec, architecture, risks, plan, generic).
- `config.json` – example run config (sections, personas, coverage topics).
- `manifest_template.csv` – CSV schema for chunks.
- `run_controller.py` – reference Python driver with TODO stubs for LLM calls.

## Quick Start
1. Fill `manifest_template.csv` with your chunks.
2. Update `config.json` with your sections, personas, coverage topics, and <PROMPT>.
3. Run `python run_controller.py` (it will validate coverage & schemas and print missing pieces).

> The driver shows how to **fail-closed**. Wire your LLM calls where marked (OpenAI/Anthropic/etc.).

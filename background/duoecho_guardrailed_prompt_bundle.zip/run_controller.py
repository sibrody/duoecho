#!/usr/bin/env python3
import json, csv, re, sys, os, textwrap
from collections import defaultdict

def load_manifest(path):
    rows=[]
    with open(path, newline='', encoding='utf-8') as f:
        for r in csv.DictReader(f):
            rows.append(r)
    return rows

def add_neighbors(selected_ids, manifest):
    ids = [c["chunk_id"] for c in manifest]
    idx = {cid:i for i,cid in enumerate(ids)}
    sel=set(selected_ids)
    out=list(selected_ids)
    for cid in selected_ids:
        i = idx.get(cid); 
        if i is None: continue
        if i>0: out.append(ids[i-1])
        if i<len(ids)-1: out.append(ids[i+1])
    # same-title siblings
    titles = {next(c["section_title"] for c in manifest if c["chunk_id"]==cid) for cid in selected_ids}
    out += [c["chunk_id"] for c in manifest if c["section_title"] in titles]
    # dedupe preserving order
    seen=set(); final=[]
    for x in out:
        if x not in seen: final.append(x); seen.add(x)
    return final

def select_for_section(section, manifest, keywords, k=8):
    sel=[c["chunk_id"] for c in manifest if any(kw.lower() in (c["section_title"]+" "+c["summary"]).lower() for kw in keywords)]
    sel=add_neighbors(sel, manifest)
    return sel[:k]

def retrieve_text(ids, manifest, full_text_loader=None):
    # Placeholder: load text using your own storage; here we fake with 'summary'
    texts=[]
    for cid in ids:
        c = next(c for c in manifest if c["chunk_id"]==cid)
        texts.append({"chunk_id":cid, "text": f"{c['section_title']}\n{c['summary']}\n"})
    return texts

def validate_schema(output_json, schema):
    # Minimal schema check: required fields exist
    missing=[k for k in schema.get("required",[]) if k not in output_json]
    return (len(missing)==0, missing)

def run_worker(section, chunk_set, worker_cfg, prompt_ctx, schema):
    # TODO: call your LLM here. For now, emit a stub that passes validation.
    evidence=[c["chunk_id"] for c in chunk_set[:2]]
    if section=="Executive":
        out={"summary":"<stub>", "top_risks":["<stub>"], "next_experiment":"<stub>", "evidence_chunk_ids":evidence}
    elif section=="Architecture":
        out={"components":["<stub>"], "data_flows":["<stub>"], "constraints":["<stub>"], "evidence_chunk_ids":evidence}
    elif section=="Risks":
        out={"technical":["<stub>"], "security":["<stub>"], "ux":["<stub>"], "mitigations":["<stub>"], "evidence_chunk_ids":evidence}
    elif section=="Plan":
        out={"phases":["<stub>"], "gates":["<stub>"], "metrics":["<stub>"], "evidence_chunk_ids":evidence}
    else:
        out={"summary":"<stub>", "key_points":["<stub>"], "evidence_chunk_ids":evidence}
    return out

def enforce_guardrails(sections_out, config, manifest):
    # Coverage
    missing_topics=[]
    for t in config["coverage_topics"]:
        cited=False
        for sec_name, sec_data in sections_out.items():
            if sec_name in t["target_sections"]:
                if sec_data.get("evidence_chunk_ids"):
                    # weak check: any evidence; tighten by checking keywords
                    cited=True
        if not cited:
            missing_topics.append(t["name"])
    # Citations presence
    bad_sections=[s for s,d in sections_out.items() if not d.get("evidence_chunk_ids")]
    status="complete" if not missing_topics and not bad_sections else "incomplete"
    return status, {"missing_topics":missing_topics, "bad_sections":bad_sections}

def main():
    manifest_path = os.environ.get("MANIFEST","manifest_template.csv")
    config_path = os.environ.get("CONFIG","config.json")
    manifest = load_manifest(manifest_path)
    config = json.load(open(config_path))
    outputs={}
    for section in config["target_sections"]:
        wcfg = config["workers"].get(section, config["workers"]["default"])
        ids = select_for_section(section, manifest, wcfg.get("keywords",[]), k=8)
        chunk_set = retrieve_text(ids, manifest)
        schema = json.load(open(wcfg["schema"]))
        out = run_worker(section, chunk_set, wcfg, {
            "prompt_text": config["prompt_text"],
            "persona_delta": config["persona_delta"],
            "tone_knobs": config["tone_knobs"]
        }, schema)
        ok, missing = validate_schema(out, schema)
        if not ok:
            print(f"[ERROR] Schema fail in {section}: missing {missing}")
            sys.exit(1)
        outputs[section]=out
    status, gaps = enforce_guardrails(outputs, config, manifest)
    print("STATUS:", status)
    if status!="complete":
        print("GAPS:", json.dumps(gaps, indent=2))
    else:
        print("OUTPUTS:", json.dumps(outputs, indent=2))

if __name__=="__main__":
    main()
